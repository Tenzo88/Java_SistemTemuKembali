
package FileCrawler;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.LinkedList;


import Architecture.ByteBuffer;
public class FolderReader {
    private LinkedList<String> allfiles = new LinkedList<String>();
		public static void main(String args[]) {
			FolderReader fr = new FolderReader();
			
			fr.listAllFiles(new File("maildir"));
			for(String filePath : fr.allfiles) {
				try {
					String content = fr.readFile(new File(filePath));
					System.out.println(filePath+" : "+content.substring(0, 100));
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		private void listAllFiles(File root) {
			for (File file : root.listFiles()) {
				if (file.isDirectory()) {
					listAllFiles(file);
				} else if (file.isFile()) {
					allfiles.add(file.getAbsolutePath());
				}
			}
		}
		
	public String readFile(File myfile) throws IOException {
		BufferedInputStream in = new BufferedInputStream(new FileInputStream(myfile));
		ByteBuffer buffer = new ByteBuffer();
		byte[] buf = new byte[1024];
		int len;
		while ((len = in.read(buf)) != -1) {
			buffer.put(buf, len);
		}
		in.close();
		return new String(buffer.buffer, 0, buffer.write);
	}
}

package QueryProcessing;

import Architecture.ByteBuffer;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

public class SympleQueryTest {
    private HashMap<String, HashMap<Integer, Integer>> indexes;

    public SympleQueryTest() {
        indexes = new HashMap<String, HashMap<Integer, Integer>>();
    }
            
    private String readFile(File myfile) throws IOException {
        BufferedInputStream in = new BufferedInputStream(new FileInputStream(myfile));
        ByteBuffer buffer = new ByteBuffer();
        byte[] buf = new byte[1024];
        int len;
        while ((len = in.read(buf)) != -1) {
            buffer.put(buf, len);
        }
        in.close();
        return new String(buffer.buffer,0,buffer.write) + "\n";
    }
    
    public void loadIndex(String filename) {
        try {
            String context = readFile(new File(filename));
            String[] docs = context.split("\n");
            for (String doc : docs) {
                String[] row = doc.split("\\|");
                String keyword = row[0];
                HashMap<Integer, Integer> index = new HashMap<Integer, Integer>();

                if (row.length == 2) {
                    String[] chunk = row[1].split(",");
                    for (String docFreqPair : chunk) {
                        String[] pair = docFreqPair.split(":");
                        int docID = Integer.parseInt(pair[0]);
                        int freq = Integer.parseInt(pair[1]);
                        index.put(docID, freq);
                    }
                }
                indexes.put(keyword, index);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public void printIndexes() {
        for (Map.Entry<String, HashMap<Integer, Integer>> set : indexes.entrySet()) {
            System.out.print(set.getKey() + ":");

            for (Map.Entry<Integer, Integer> id : set.getValue().entrySet()) {
                System.out.print(id.getKey() + ":" + id.getValue() + ", ");
            }
            System.out.println();
        }
    }
    
    public void seach(String queryText){
        String[] qss = queryText.split(" ");
        //System.out.println(indexes);
        HashSet<Integer>resultSet = new HashSet<Integer>();
         System.out.println(indexes.keySet());
        for(String qs:qss){
             System.out.println(qs);
            System.out.println(indexes.get(qs));
            HashMap<Integer,Integer> docs = indexes.get(qs);
            if(docs!=null)
                for( Integer docID : docs.keySet()){
                    resultSet.add(docID);
                }
        }
        System.out.println("query with keyword (s)["+queryText+"] exist in" 
                + resultSet.size()+"  documents : ");
                for(Integer docID : resultSet){
                    System.out.println(docID);
                }
    }
    
    public static void main(String[] args){
        SympleQueryTest SQT =new SympleQueryTest();
        SQT.loadIndex("hasil.txt");
        SQT.printIndexes();
        System.out.println(" ---------------- Query Test ----------- ");
        SQT.seach("telapak");
    }
            
}

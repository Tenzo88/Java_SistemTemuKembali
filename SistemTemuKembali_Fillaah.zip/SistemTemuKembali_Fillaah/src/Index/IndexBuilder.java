/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Index;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map.Entry;
import java.util.StringTokenizer;


/**
 *
 * @author ACER
 */
public class IndexBuilder {
    private String[] dokumen;
    private String stopWords[] = { "di", "akan", "adalah", " sama", " dan"};
    private HashMap<String, LinkedList<Integer> > indexes;
    
    public IndexBuilder (String[] dokumen) {
      this.dokumen = dokumen;
      indexes = new HashMap <String, LinkedList<Integer>>();
    }
    public void buildIndex(){
        for (int i=0; i<dokumen.length;i++){
            String dok = dokumen[i].toLowerCase();
            StringTokenizer st = new StringTokenizer(dok,"!*^/-.|() ?%,;");
             while(st.hasMoreTokens()) {
                 String token = st.nextToken();
                 if(token.length()>= 3 && !contains(stopWords,token)){
                     LinkedList<Integer> list = indexes.get(token);
                     if (list == null) {
                         list = new LinkedList<Integer>();
                         indexes.put(token,list);
                     }
                     list.add(1);
                 }
             }
        }
    }
    
    public void printIndexes() {
    for(Entry<String, LinkedList<Integer>> set : indexes.entrySet()) {
            System.out.print(set.getKey()+" : ");
            for(int id:set.getValue()){
                System.out.print(id+ " , ");
            }
            System.out.println();
        }
    }
    
    private boolean contains(String[] arr, String targetValue) {
        for (String s: arr){
            if (s.equals(targetValue))
                return true;
        }
        return false;
    }
    
    private boolean loadDocuments(String folder) {
        return false;
    }
    
    public static void main(String[]args) {
        String dokumen[] = new String[5];
        dokumen[0]="Dunia tak lagi sama tak selamanya memihak kita, di saat kita berusaha di situlah kebahagiaan akan indah pada waktunya.";
        dokumen[1]="Hidup ini hanya sekali dan peluang itu juga sekali munculnya";
        dokumen[2]="Hidup tak semudah membalikan telapak tangan, tetapi dengan telapak tangan kita dapat mengubah hidup kita jauh lebih baik lagi.";
        dokumen[3]="jadilah pribadi yang menantang masa depan,bukan pengecut yang aman dizona nyaman ";
        dokumen[4]="belajarlah rendah hati rendahkan hatimu serendah rendahnya";
    IndexBuilder inv = new IndexBuilder(dokumen);
    inv.buildIndex();
    inv.printIndexes();
    }
}

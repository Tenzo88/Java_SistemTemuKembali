/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Architecture;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.Buffer;

public class FileReader {
    public static void main(String args[]) {
		try {
			String content = readFile(new File("maildir/3"));
			System.out.println(content);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	public static String readFile(File myfile) throws IOException {
		BufferedInputStream in = new BufferedInputStream(new FileInputStream(myfile));
		ByteBuffer buffer = new ByteBuffer();
		byte[] buf = new byte[1024];
		int len;
		while ((len = in.read(buf)) != -1) {
			buffer.put(buf, len);
		}
		in.close();
		return new String(buffer.buffer, 0, buffer.write);
	}
}

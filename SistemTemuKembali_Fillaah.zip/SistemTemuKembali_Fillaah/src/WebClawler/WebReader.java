
package WebClawler;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

public class WebReader {
    public static void main(String[] args) {
		URL url;
		try {
String a="https://WWW.Cnnindonesia.com/nasional/20230307102532-12-921837/ppatk-juga-blokir-rekening-mario-dandy-anak-rafael-alun";
			
			url = new URL(a);
			URLConnection conn =
					url.openConnection();
			BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			String inputLine;
		    
		    while ((inputLine=br.readLine()) != null) {
		    	
		    	System.out.println(inputLine);
		    }
		    br.close();
		}  catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}

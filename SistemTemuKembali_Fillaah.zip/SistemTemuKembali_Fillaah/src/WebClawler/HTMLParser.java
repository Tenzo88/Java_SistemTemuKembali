
package WebClawler;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;


import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.safety.Cleaner;
import org.jsoup.safety.Safelist;

public class HTMLParser {
    public static void main(String[] args) {
		URL url;
		try {
			String a="https://WWW.Cnnindonesia.com/nasional/20230307102532-12-921837/ppatk-juga-blokir-rekening-mario-dandy-anak-rafael-alun";
			
			url = new URL(a);
			URLConnection conn =
					url.openConnection();
			BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			String inputLine;
			
		    StringBuilder sb = new StringBuilder();
		    String line;
		    
		    while ((line=br.readLine()) != null) {
		    	sb.append(line);
		    }
		    Document doc = Jsoup.parseBodyFragment(sb.toString());
		    Cleaner cleaner = new Cleaner(Safelist.none());
		    Document normalizedDoc = cleaner.clean(doc);
		    Element body = normalizedDoc.body();
		   System.out.println(body.html());
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}

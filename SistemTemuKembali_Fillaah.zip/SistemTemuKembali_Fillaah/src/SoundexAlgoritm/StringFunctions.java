package SoundexAlgoritm;

public class StringFunctions {
    /**
     *  Removes all the spaces in a given String.
     *  E.g:    : "A B CDD" becomes "ABCDD"  
     */ 
    public static String squeeze (String in) {
        String temp = "";
        StringBuilder sb = new StringBuilder(in.trim());
        int i = 0;

        while (i < sb.length()) {
            if (sb.charAt(i) == ' ') {
                // Starting with the current position, shift all 
                // the characters from right to left. 
                for (int j=i; j < sb.length() - 1; j++) 
                    sb.setCharAt(j, sb.charAt(j+1));

                // The length of string is reduced by 1
                temp = sb.substring(0, sb.length()-1);

                sb.setLength(0);
                sb.append(temp);
            }

            // After shifting the characters from right to left, the new
            // character in the current position might be a Space.  If so,
            // the same position has to be processed again .
            if (sb.charAt(i) != ' ')
                i++; 
        }
        return sb.toString();
    }

    /**
     *  Removes Continuous Duplicate characters in a string.
     *  E.g: "AAABCCCDDDBB" becomes "ABCDB"
     */

    public static String removeContDupChars(String in ) {
        String temp = "";
        StringBuilder sb = new StringBuilder(in);
        int i = 0;
        char prevChar;

        while (i < sb.length()) {
            prevChar = sb.charAt(i);
            for (int j=i+1; j<sb.length(); j++) {
                // As long as there are same characters, Replace all the Duplicates
                // with Space. 
                if (prevChar == sb.charAt(j))
                    sb.setCharAt(j, ' ');
                else
                    // Where there is a different char, break the inner loop.
                    break;
            }
            i++;
        }
        return squeeze(sb.toString());
    }
}
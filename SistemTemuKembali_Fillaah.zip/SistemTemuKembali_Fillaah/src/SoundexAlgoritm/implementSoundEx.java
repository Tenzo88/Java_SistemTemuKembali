
package SoundexAlgoritm;

import static SoundexAlgoritm.SoundExClass.dropChars;
import static SoundexAlgoritm.SoundExClass.map;
import static SoundexAlgoritm.SoundExClass.notvowels;
import static SoundexAlgoritm.SoundExClass.vowels;
import java.util.Arrays;


public class implementSoundEx {

    private String inputString;
    public String implementSoundEx() {
    String temp = StringFunctions.removeContDupChars(inputString);
    StringBuilder sb = new StringBuilder(temp);

    // If the first and second characters have the same number
    // Replace the second character with Space. 
    if (map.get(sb.charAt(0)) == map.get(sb.charAt(1))){
        sb.setCharAt(1, ' ');
    }

    // Replace the consonants with their corresponding mapped numbers.
    // Do this for all characters, except the First char.
    for (int i = 1; i < sb.length(); i++) {
        if (sb.charAt(i) != ' ' ){
            sb.setCharAt(i, map.get(sb.charAt(i)));
        }
    }

    // Repeat the processing starting with the Second character. 
    for (int i = 1; i < sb.length() - 1; i++) {
        // If the current character is any of A,E,I,O,U,Y,H,W or Space, ignore it.  
        // Process the next character.
        if ((Arrays.binarySearch(dropChars, sb.charAt(i)) != -1) || (sb.charAt(i) == ' ')){
            continue;   
        }

        // If two or more letters with the same number are adjacent in, only retain the first letter;
        // For this, put a space in the next character.
        if (sb.charAt(i) == sb.charAt(i + 1)){
            sb.setCharAt(i + 1, ' ');
        }

        // Two letters with the same number separated by 'H' or 'W' are coded as a single number
        if (i + 2 < sb.length() &&
            sb.charAt(i) == sb.charAt(i + 2) &&
            Arrays.binarySearch(notvowels, sb.charAt(i + 1)) != -1
        ){
            sb.setCharAt(i + 2, ' ');
        }           
    }

    // Replace all the vowels with Spaces. 
    for (int i = 1; i < sb.length(); i++) {
        if (Arrays.binarySearch(vowels, sb.charAt(i)) != -1){
            sb.setCharAt(i, ' ');
        }
    }

    return StringFunctions.squeeze(sb.toString()).substring(0, 4);
}
}

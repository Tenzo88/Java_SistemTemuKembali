
package SoundexAlgoritm;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

class SoundExClass {
    public final static Map<Character, Character> map = new HashMap<Character, Character>() {{
        put('B', '1');
        put('F', '1');
        put('P', '1');
        put('V', '1');
        put('C', '2');
        put('G', '2');
        put('J', '2');
        put('K', '2');
        put('Q', '2');
        put('S', '2');
        put('X', '2');
        put('Z', '2');
        put('D', '3');
        put('T', '3');
        put('L', '4');
        put('M', '5');
        put('N', '5');
        put('R', '6');
        put('A', 'A');
        put('E', 'E');
        put('I', 'I');
        put('O', 'O');
        put('U', 'U');
        put('Y', 'Y');
        put('H', 'H');
        put('W', 'W');
    }};

    public char getValue(char ch) {
        char value = map.get(ch);
        return value;
    }

    public final static char[] vowels = {'A', 'E', 'I', 'O', 'U'};

    public final static char[] notvowels = {'H', 'W'};

    public final static char[] dropChars = {'A', 'E', 'I', 'O', 'U', 'Y', 'H', 'W'};

    private String inputString;

    public SoundExClass(String inputString) {
        //this.inputString = Arrays.asList(inputString);
        this.inputString = inputString.toUpperCase().trim();
    }

    public String implementSoundEx() {
        StringBuilder sb = new StringBuilder(inputString);
        char currentChar, nextChar = ' ';

        // Remove continuous duplicate characters from the String. 
        // E.g, After the function call, a String 'AAABBBCCCDD' becomes 'ABCD'
        String temp = StringFunctions.removeContDupChars(sb.toString());

        sb.setLength(0);
        sb.append(temp);

        // If the first and second characters have the same number
        // Replace the second character with Space. 
        if (getValue(sb.charAt(0)) == getValue(sb.charAt(1)))
            sb.setCharAt(1, ' ');

        // Replace the consonants with their corresponding mapped numbers.
        // Do this for all characters, except the First char.
        for (int i=1; i < sb.length(); i++) {
            if (sb.charAt(i) != ' ' )
                sb.setCharAt(i, getValue(sb.charAt(i)));
        }

        // Repeat the processing starting with the Second character. 
        for (int i=1; i < sb.length(); i++) {
            currentChar = sb.charAt(i);

            // If the current character is any of A,E,I,O,U,Y,H,W or Space, ignore it.  
            // Process the next character.
            if ((Arrays.binarySearch(dropChars, currentChar) != -1) || (currentChar == ' '))
                continue;   

            // If two or more letters with the same number are adjacent in, only retain the first letter;
            // For this, put a space in the next character.
            if (i+1 < sb.length()) {
                nextChar = sb.charAt(i+1);

                if (currentChar == nextChar)
                    sb.setCharAt(i+1, ' ');
            }

            // Two letters with the same number separated by 'H' or 'W' are coded as a single number
            if (i+2 < sb.length()) {
                if (currentChar == sb.charAt(i+2))
                    if (Arrays.binarySearch(notvowels, nextChar) != -1)
                        sb.setCharAt(i+2, ' ');  
            }
        }

        // Replace all the vowels with Spaces. 
        for (int i=1; i < sb.length(); i++) {
            if (Arrays.binarySearch(vowels, sb.charAt(i)) != -1)
                sb.setCharAt(i, ' ');
        }

        // 
        String x = sb.toString(); 
        return StringFunctions.squeeze(x).substring(0, 4);
    }
}

class SoundEx {
    public static void main(String ...strings) {
        SoundExClass soundex = new SoundExClass("Ashcraft");
        System.out.println(soundex.implementSoundEx());
    }
}

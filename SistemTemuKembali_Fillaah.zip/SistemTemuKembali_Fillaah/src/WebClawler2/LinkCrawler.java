
package WebClawler2;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayDeque;
import java.util.HashSet;
import java.util.Queue;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class LinkCrawler {
    private Queue<URL> urlQueue;
	private HashSet<URL> collectedUrl;
	private String domainScope;
	public LinkCrawler() {
		urlQueue = new ArrayDeque<URL>();
		collectedUrl = new HashSet<URL>();
		
		try {
			URL seed = new URL("https://WWW.cnnindonesia.com");
			domainScope = seed.getHost();
			
			System.out.println(domainScope);
			urlQueue.add(seed);
			
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
		
		int limit = 100; // batas jumlah link yang boleh di kunjungi; hnya untuk percobaan 
		int i=0;
		while(!urlQueue.isEmpty() && i<limit) {
			getLinks(urlQueue.poll());
			i++;
			
		}
	}
	
	public static void main(String args[]) {
		new LinkCrawler();
	}
	
	private void getLinks(URL url) {
		collectedUrl.add(url);
		
		try {
			URLConnection conn = url.openConnection();
			BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			String inputLine;
			
			StringBuilder sb = new StringBuilder();
			String line;
			while ((line = br.readLine()) != null) {
				sb.append(line);
				
			}
			Document doc = Jsoup.parseBodyFragment(sb.toString());
			Elements links = doc.select("a[href]");
			
			int index = 0;
			for (Element link : links) {
				String absUrl = link.attr("abs:href");
				if (absUrl.length() > 0) {
					try {
						URL newUrl = new URL(absUrl);
						if(newUrl.getHost().equalsIgnoreCase(domainScope)&& !collectedUrl.contains(newUrl)) {
							urlQueue.add(newUrl);
							collectedUrl.add(newUrl);
							System.out.println(newUrl);
						}
					} catch (MalformedURLException ex) {}
					
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}

package Indexing2;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.StringTokenizer;


public class SerializeIndex {
    
    private final String[] dokumen;
    private final String stopWords[] = {"di", "akan", "adalah", "sama", "dan"};
    private HashMap<String, HashMap<Integer, Integer>> indexes;
    
    public SerializeIndex(String[] dokumen) {
        this.dokumen = dokumen;
        indexes = new HashMap<>();
    }
    
    public void buildIndex() {
        for (int i = 0; i < dokumen.length; i++) {
            String dok = dokumen[i].toLowerCase();
            StringTokenizer st = new StringTokenizer(dok, "!*^/-.|() ?%,;");

            while (st.hasMoreTokens()) {
                String token = st.nextToken();
                if (token.length() >= 3 && !contains(stopWords, token)) {
                    HashMap<Integer, Integer> list = indexes.get(token);
                    if (list == null) {
                        list = new HashMap<>();
                        indexes.put(token, list);
                    }
                    if (list.containsKey(i)) {
                        list.put(i, list.get(i) + 1);
                    } else {
                        list.put(i, 1);
                    }
                }
            }
        }
    }
    
    public void printIndexes() {
        for (Entry<String, HashMap<Integer, Integer>> set : indexes.entrySet()) {
            System.out.print(set.getKey() + ":");

            for (Entry<Integer, Integer> id : set.getValue().entrySet()) {
                System.out.print(id.getKey() + ":" + id.getValue() + ", ");
            }
            System.out.println();
        }
    }
    
    private boolean contains(String[] arr, String targetValue) {
        for (String s: arr){
            if (s.equals(targetValue))
                return true;
        }
        return false;
    }
    
    private void saveIndex(String path){
        FileOutputStream fos;
        try {
            fos = new FileOutputStream(path);
            try (ObjectOutputStream oss = new ObjectOutputStream(fos)) {
                oss.writeObject(indexes);
                oss.flush();
            }
            System.out.println("Success");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    private void loadIndex(String path) {
        ObjectInputStream in;
        try {
            in = new ObjectInputStream(new FileInputStream(path));
            indexes = (HashMap<String, HashMap<Integer, Integer>>) in.readObject();
            in.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
    
    public static void main(String[] args) {
        String dokumen[] = new String[5];
        dokumen[0] = "Dunia tak lagi sama tak selamanya memihak kita, di saat kita berusaha di situlah kebahagiaan akan indah pada waktunya.";
        dokumen[1] = "Hidup ini hanya sekali dan peluang itu juga sekali munculnya";
        dokumen[2] = "Hidup tak semudah membalikan telapak tangan, tetapi dengan telapak tangan kita dapat mengubah hidup kita jauh lebih baik lagi.";
        dokumen[3] = "jadilah pribadi yang menantang masa depan,bukan pengecut yang aman dizona nyaman ";
        dokumen[4]="belajarlah rendah hati rendahkan hatimu serendah rendahnya";
        SerializeIndex inv = new SerializeIndex(dokumen);
        inv.buildIndex();
        System.out.println("**** Index Built : ");
        inv.printIndexes();
        inv.saveIndex("index.save");
        System.out.println("\n\n**** Index Loaded: ");
        inv.loadIndex("index.save");
        inv.printIndexes();
    }

}

package Indexing2;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map.Entry;

import Architecture.ByteBuffer; //ambil nilai dari package & file byte buffer

public class LoadSaveIndex {
    private HashMap<String, HashMap<Integer, Integer>> indexes;

    public LoadSaveIndex() {
        indexes = new HashMap<>();
    }
    
    private String readFile(File myfile) throws IOException {
        BufferedInputStream in = new BufferedInputStream(new FileInputStream(myfile));
        ByteBuffer buffer = new ByteBuffer();
        byte[] buf = new byte[1024];
        int len;
        while ((len = in.read(buf)) != -1) {
            buffer.put(buf, len);
        }
        in.close();
        return new String(buffer.buffer,0,buffer.write) + "\n";
    }

    public void loadIndex(String filename) {
        try {
            String context = readFile(new File(filename));
            String[] docs = context.split("\n");
            for (String doc : docs) {
                String[] row = doc.split("\\|");
                String keyword = row[0];
                HashMap<Integer, Integer> index = new HashMap<Integer, Integer>();

                if (row.length == 2) {
                    String[] chunk = row[1].split(",");
                    for (String docFreqPair : chunk) {
                        String[] pair = docFreqPair.split(":");
                        int docID = Integer.parseInt(pair[0]);
                        int freq = Integer.parseInt(pair[1]);
                        index.put(docID, freq);
                    }
                }
                indexes.put(keyword, index);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void printIndexes() {
        for (Entry<String, HashMap<Integer, Integer>> set : indexes.entrySet()) {
            System.out.print(set.getKey() + ":");

            for (Entry<Integer, Integer> id : set.getValue().entrySet()) {
                System.out.print(id.getKey() + ":" + id.getValue() + ", ");
            }
            System.out.println();
        }
    }

    public static void main(String[] args) {
        LoadSaveIndex inv = new LoadSaveIndex();
        inv.loadIndex("hasil.txt");
        inv.printIndexes();
    }
}

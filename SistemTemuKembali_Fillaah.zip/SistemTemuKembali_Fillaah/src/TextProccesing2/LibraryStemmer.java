
package TextProccesing2;


import java.util.HashMap;
import IndonesianNLP.IndonesianStemmer;
import java.util.StringTokenizer;

public class LibraryStemmer {
    public static void main(String[] args) {
        String kalimat = "Temukan dia untukku "+
                "Pulangkan dia padaku "+
                " Bahwa ku tetap di sini "+
                " Temukan dia untukku "+
                " Pulangkan dia padaku "+
                "Tunjukkan jalan padanya "+
                "Bahwa ku tetap di sini untuknya "+
                "Berharap dia kembali pulang untukku "+
                "Coba kau rasakan sayang";
        
        kalimat = kalimat.toLowerCase();
        System.out.println(kalimat);
        System.out.println("\n--- Tokenisasi dengan StringTokenizer ---");
        StringTokenizer st = new StringTokenizer(kalimat,"!*^/-.|() ?%,;");
        IndonesianStemmer stemmer = new IndonesianStemmer();
        
        while (st.hasMoreTokens()){
            String token = st.nextToken();
            System.out.println("Utuh : "+token);
            System.out.println("Hasil: "+stemmer.stem(token));
            System.out.println();
        }
    }
}
package TextProccesing2;

import java.util.HashMap;
import java.util.StringTokenizer;

public class DictionaryBasedStem {
    public static void main(String[] args) {
        
        String dictText = "temukan:temu;"
                +"pulangkan:pulang;"
                +"tunjukkan:tunjuk;"
                +"berharap:harap;"
                +"teramatlah:teramat;"
                +"penantian:nanti;"
                +"rasakan:rasa;"
                +"terindah:indah;"
                +"membawa:bawa;"
                +"menghilang:hilang;"
                +"sepilu:pilu;"
                +"pilunya:pilu;"
                +"mengharap:harap;";
        HashMap<String, String> dictionary = buildDictionary(dictText.toLowerCase());
        String kalimat = " Temukan  dia  untukku "+
                " Pulangkan  dia  padaku "+
                " Bahwa ku  tetap  di  sini"+
                " Temukan dia untukku "+
                " Pulangkan  dia  padaku "+
                " Tunjukkan  jalan  padanya "+
                " Bahwa  ku  tetap  di  sini  untuknya "+
                " Berharap  dia  kembali  pulang  untukku"+
                " Coba  kau  rasakan  sayang ";
        
        kalimat = kalimat.toLowerCase();
        System.out.println(kalimat);
        System.out.println("\n--- Tokenisasi dengan StringTokenizer ---");
        StringTokenizer st = new StringTokenizer(kalimat,"!*^/-.|() ?%,;");
        
        String stopWords[]={"di","akan","adalah","sama","dan","dengan"};
        
        while(st.hasMoreTokens()) {
            String token = st.nextToken();
            System.out.println("Utuh: "+token);
            if(token.length()>= 3 && !contains(stopWords,token)) {
                String stem = dictionary.get(token);
                if(stem == null) {
                    stem = token;
                }
                System.out.println("Hasil: "+stem);
            }
            System.out.println();
        }
    }
    
    public static boolean contains(String[] arr, String targetValue) {
        for (String s: arr) {
            if (s.equals(targetValue))
                return true;
        }
        return false;
    }
    
    public static HashMap<String, String> buildDictionary(String dictText) {
        HashMap<String, String>dictionary = new HashMap<String, String>();
        
        String[] dictArray = dictText.split(";");
        for(String element : dictArray){
            String[] tuple = element.split(":");
            dictionary.put(tuple[0], tuple[1]);
        }
        return dictionary;
    }
}

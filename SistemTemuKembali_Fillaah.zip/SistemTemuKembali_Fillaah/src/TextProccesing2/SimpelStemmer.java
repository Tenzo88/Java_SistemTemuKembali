
package TextProccesing2;

import java.util.HashMap;
import java.util.StringTokenizer;

public class SimpelStemmer {
    public static void main(String[] args) {
        String kalimat = "Temukan dia untukku "+
                "Pulangkan dia padaku "+
                "Bahwa ku tetap di sini "+
                "Temukan dia untukku "+
                "Pulangkan dia padaku "+
                "Tunjukkan jalan padanya "+
                "Bahwa ku tetap di sini untuknya "+
                "Berharap dia kembali pulang untukku "+
                "Coba kau rasakan sayang";
        
        kalimat = kalimat.toLowerCase();
        System.out.println(kalimat);
        System.out.println("\n--- Tokenisasi dengan StringTokenizer ---");
        StringTokenizer st = new StringTokenizer(kalimat,"!*^/-.|() ?%,;");
        
        
        while (st.hasMoreTokens()){
            String token = st.nextToken();
            token = removeAwalan(token);
            token = removeAkhiran(token); 
            if(token.length() >= 3) {
                System.out.println("Hasil: "+token);
            }
            System.out.println();
        }
    }
    
    public static String removeAkhiran(String input){
        if(input.endsWith("nya")){
            input = input.replaceAll("nya"," ");
            return input;
        }
        if(input.endsWith("ku")){
            input = input.replaceAll("ku"," ");
            return input;
        }
        if(input.endsWith("mu")){
            input = input.replaceAll("mu"," ");
            return input;
        }
        if(input.endsWith("kah")){
            input = input.replaceAll("kah"," ");
            return input;
        }
        if(input.endsWith("lah")){
            input = input.replaceAll("lah"," ");
            return input;
        }
        if(input.endsWith("pun")){
            input = input.replaceAll("pun"," ");
            return input;
        }
        if(input.endsWith("kan") && input.length() >6){
            input = input.replaceAll("kan"," ");
            return input;
        }
        return input;
    }
    
    public static String removeAwalan(String input) {
        if(input.startsWith("meng")){
            input = input.replaceAll("meng"," ");
            return input;
        }
        if(input.startsWith("")){
            input = input.replaceAll("men"," ");
            return input;
        }
        if(input.startsWith("mem")){
            input = input.replaceAll("mem"," ");
            return input;
        }
        if(input.startsWith("me")){
            input = input.replaceAll("me"," ");
            return input;
        }
        if(input.startsWith("peng")){
            input = input.replaceAll("peng"," ");
            return input;
        }
        if(input.startsWith("pen")){
            input = input.replaceAll("pen"," ");
            return input;
        }
        if(input.startsWith("pem")){
            input = input.replaceAll("pem"," ");
            return input;
        }
        if(input.startsWith("di")){
            input = input.replaceAll("di"," ");
            return input;
        }
        if(input.startsWith("ke")){
            input = input.replaceAll("ke"," ");
            return input;
        }
        if(input.startsWith("ter")){
            input = input.replaceAll("ter"," ");
            return input;
        }
        if(input.startsWith("ber")){
            input = input.replaceAll("ber"," ");
            return input;
        }
        return input;
    }
}

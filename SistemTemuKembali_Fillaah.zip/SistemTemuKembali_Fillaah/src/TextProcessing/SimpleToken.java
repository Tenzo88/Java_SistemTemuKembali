
package TextProcessing;


import java.util.StringTokenizer;
public class SimpleToken {
    public static void main(String args[]) {
        String kalimat = "Hallo Selamat datang di bulan maret";
        System.out.println(kalimat);
        System.out.println("\n--- Tokenisasi dengan StringTokenizer ---");
        StringTokenizer st = new StringTokenizer(kalimat);
        
        while (st.hasMoreTokens()) {
            System.out.println(st.nextToken());
        }
        
        System.out.println("\n --- Tokenisasi dengan fungsi split --- ");
        String[] mkata = kalimat.split(" ");
        for(String kata : mkata) {
            System.out.println(kata);
        }
    }
}

package TextProcessing;


import java.util.StringTokenizer;

public class ComplexTokenizer {
    public static void main(String args[]) {
        String kalimat = "Hai Guys, selamat datang di bulan maret;"
                +"Lanina membuat maret ku penuh hujan"
                +"hujan yang seringali menjatuhkan 1% air dan 90% kenangan "
                +"bukan begini teman - teman? ";
        System.out.println(kalimat);
        System.out.print("\n--- Tokenizer dengan StringTokenizer ---");
        StringTokenizer st = new StringTokenizer(kalimat,"!*^/-.|() ?%,;");
        
        while(st.hasMoreTokens()) {
            System.out.println(st.nextToken());
        }
        
        System.out.println("\n--- Tokenisasi dengan fungsi split ---");
        String[] mkata = kalimat.split("[\\-\\.\\'\\?\\,\\,\\_\\@\\;\\%]+");
        for(String kata : mkata) {
            System.out.println(kata);
        }
    }
}

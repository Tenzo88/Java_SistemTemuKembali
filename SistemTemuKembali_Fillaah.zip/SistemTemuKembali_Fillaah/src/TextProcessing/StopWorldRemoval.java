package TextProcessing;

import java.util.StringTokenizer;
public class StopWorldRemoval {
    public static void main(String[] args) {
        String kalimat = "Hai Guys, selamat datang di bulan maret; "
                +"Lanina membuat maret ku penuh hujan "
                +"Hujan yang seringkali menjatuhkan 1% air dan 90% kenangan. "
                + "Bukan begitu teman - teman? ";
        kalimat = kalimat.toLowerCase();
        System.out.println(kalimat);
        System.out.println("\n--- Tokeisasi dengan StringTokenizer ---");
        StringTokenizer st = new StringTokenizer(kalimat,"!*^/-.|() ?%,;");
        
        String stopWords[] = {"di","yang","dan"};
        while(st.hasMoreTokens()) {
            String token = st.nextToken();
            if(token.length()>= 3 && !contains(stopWords,token))
                System.out.println(token);
        }
    }
    public static boolean contains(String[] arr, String targetValue) {
        for (String s: arr) {
            if (s.equals(targetValue))
                return true;
        }
        return false;
    }
}
